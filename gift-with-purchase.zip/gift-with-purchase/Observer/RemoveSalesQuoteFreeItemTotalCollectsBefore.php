<?php


namespace Kharvi\GiftWithPurchase\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer as EventObserver;
use Magento\SalesRule\Api\Exception\CodeRequestLimitException;
use Magento\SalesRule\Model\Spi\CodeLimitManagerInterface;

class RemoveSalesQuoteFreeItemTotalCollectsBefore implements ObserverInterface
{
    /**
     * @var \Magento\Checkout\Model\Session
     */
    private $checkoutSession;

    /**
     * @var \Magento\Checkout\Model\Cart
     */
    private $cartSession;

    /**
     * RemoveSalesQuoteFreeItemTotalCollectsBefore constructor.
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Magento\Checkout\Model\Cart $cartSession
     */
    public function __construct(
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Checkout\Model\Cart $cartSession
    ) {
        $this->checkoutSession = $checkoutSession;
        $this->cartSession = $cartSession;
    }

    /**
     * @param EventObserver $observer
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function execute(EventObserver $observer)
    {
        $quote = $this->checkoutSession->getQuote();

        $originalStore = $quote->getStoreId();
        foreach ($quote->getAllItems() as $item) {
            if ($item->getIsFreeProduct()) {
                $quote->removeItem($item->getId());
            }
        }
        
        $this->checkoutSession->unsFreeProductApplied();
        $this->checkoutSession->unsFreeGiftApplied();

        $quote->setStoreId($originalStore);
    }
}
