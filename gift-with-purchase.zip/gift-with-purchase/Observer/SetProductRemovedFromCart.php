<?php

namespace Kharvi\GiftWithPurchase\Observer;

use Magento\Framework\Event\ObserverInterface;

class SetProductRemovedFromCart implements ObserverInterface
{
    /**
     * @var \Magento\Checkout\Model\Session
     */
    private $checkoutSession;

    /**
     * @var \Magento\Quote\Model\Quote\Item
     */
    private $quoteItemModel;

    /**
     * SetProductRemovedFromCart constructor.
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Magento\Quote\Model\Quote\Item $quoteItemModel
     */
    public function __construct(
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Quote\Model\Quote\Item $quoteItemModel
    ) {
        $this->checkoutSession = $checkoutSession;
        $this->quoteItemModel = $quoteItemModel;
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $request = $observer->getRequest();
        $params = $request->getParams(); //get params
        $action = $request->getActionName();
        $controller = $request->getControllerName();
        $method = $request->getServer('REQUEST_METHOD');

        //extra checks to avoid any issue in future
        if ($method == 'POST' && $controller == 'cart' && $action == 'delete') {
            if (isset($params['id'])) {
                $quoteItemId = $params['id'];
                $quoteItem = $this->quoteItemModel->load($quoteItemId);
                if (!empty($quoteItem) && $quoteItem->getIsFreeProduct()) {
                    $this->checkoutSession->setRemovedFreeProduct(1);
                }
            }
        }
    }
}
