<?php
/**
 * Copyright © 2020-2025 Chalhoub Group. All rights reserved.
 */

namespace Kharvi\GiftWithPurchase\Observer;

use Magento\Framework\Event\ObserverInterface;

class SetProductRemovedFromCart implements ObserverInterface
{
    /**
     * @var \Magento\Checkout\Model\Session
     */
    private $checkoutSession;

    /**
     * @var \Magento\Framework\App\Request\Http
     */
    private $request;

    /**
     * SetProductRemovedFromCart constructor.
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Magento\Framework\App\Request\Http $request
     */
    public function __construct(
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Framework\App\Request\Http $request
    ) {
        $this->checkoutSession = $checkoutSession;
        $this->request = $request;
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $quoteItem = $observer->getEvent()->getQuoteItem(); //get item
        $action     = $this->request->getActionName();
        $controller = $this->request->getControllerName();
        $method = $this->request->getServer('REQUEST_METHOD');

        if ($method == 'POST' && $controller == 'cart' && $action == 'delete'
            && !empty($quoteItem) && $quoteItem->getIsFreeProduct()) {
            $this->checkoutSession->setRemovedFreeProduct(1);
        }
    }
}
