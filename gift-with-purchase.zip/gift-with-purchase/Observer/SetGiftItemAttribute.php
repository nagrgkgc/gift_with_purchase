<?php
/**
 * Copyright © 2020-2025 Chalhoub Group. All rights reserved.
 */

namespace Kharvi\GiftWithPurchase\Observer;
 
use Magento\Framework\Event\ObserverInterface;
 
class SetGiftItemAttribute implements ObserverInterface
{
    /**
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $quoteItem = $observer->getQuoteItem();
        $product = $observer->getProduct();
        if ($product->getIsFreeProduct()) {
            $quoteItem->setIsFreeProduct(1);
        }
    }
}
