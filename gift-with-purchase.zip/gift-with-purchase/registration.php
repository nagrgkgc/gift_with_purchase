<?php
/**
 * Copyright © 2020-2025 Chalhoub Group. All rights reserved.
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Kharvi_GiftWithPurchase',
    __DIR__
);
