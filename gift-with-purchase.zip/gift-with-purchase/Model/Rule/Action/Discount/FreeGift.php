<?php

namespace Kharvi\GiftWithPurchase\Model\Rule\Action\Discount;

class FreeGift extends \Magento\SalesRule\Model\Rule\Action\Discount\AbstractDiscount
{
    /**
     * @var \Magento\Checkout\Model\Session
     */
    private $checkoutSession;

    /**
     * @var \Magento\Framework\Message\ManagerInterface
     */
    private $messageManager;

    /**
     * @var \Magento\SalesRule\Model\Rule\Action\Discount\DataFactory
     */
    protected $discountFactory;

    /**
     * @var \Kharvi\GiftWithPurchase\Helper\Data
     */
    private $helper;

    /**
     * FreeGift constructor.
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Magento\Framework\Message\ManagerInterface $messageManager
     * @param \Magento\SalesRule\Model\Rule\Action\Discount\DataFactory $discountDataFactory
     * @param \Kharvi\GiftWithPurchase\Helper\Data $helper
     */
    public function __construct(
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\SalesRule\Model\Rule\Action\Discount\DataFactory $discountDataFactory,
        \Kharvi\GiftWithPurchase\Helper\Data $helper
    ) {
        $this->checkoutSession = $checkoutSession;
        $this->messageManager = $messageManager;
        $this->discountFactory = $discountDataFactory;
        $this->helper = $helper;
    }

    /**
     * @param \Magento\SalesRule\Model\Rule $rule
     * @param \Magento\Quote\Model\Quote\Item\AbstractItem $item
     * @param float $qty
     * @return Data
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function calculate($rule, $item, $qty)
    {
        $discountData = $this->_calculate();
        $this->checkoutSession->setFreeGiftApplied(1);

        //get quote
        $quote = $this->checkoutSession->getQuote(); //get quote

        //get sku
        $sku = $rule->getGiftSku();
        $qty = $rule->getDiscountQty();

        //check if empty field
        if (empty($sku) || $qty==0) {
            return $discountData;
        }

        $this->helper->removeCoupon($quote, $sku, $qty, $rule);
        if ($item->getIsFreeProduct()
            || $this->checkoutSession->getRemovedFreeProduct()
            || $this->checkoutSession->getFreeProductApplied()
            || $this->helper->validateGiftProduct($sku, $qty)) {
            return $discountData;
        }

        try {
            $freeItem = $this->helper->_getFreeQuoteItem($sku, $item->getStoreId(), $qty);

            if (!empty($freeItem)) {
                $quote->addItem($freeItem);
                $freeItem->setApplyingRule($rule);
                $this->checkoutSession->setFreeProductApplied(1);
            }
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            throw new \Exception(sprintf(
                $e->getMessage()
            ));
        }

        return $discountData;
    }

    /**
     * @param float $qty
     * @param \Magento\SalesRule\Model\Rule $rule
     * @return float
     */
    public function fixQuantity($qty, $rule)
    {
        $step = $rule->getDiscountStep();
        if ($step) {
            $qty = floor($qty / $step) * $step;
        }

        return $qty;
    }

    /**
     * @param \Magento\SalesRule\Model\Rule $rule
     * @param \Magento\Quote\Model\Quote\Item\AbstractItem $item
     * @param float $qty
     * @param float $rulePercent
     * @return Data
     */
    protected function _calculate()
    {
        $discountData = $this->discountFactory->create();
        return $discountData;
    }
}
