<?php
/**
 * Copyright © 2020-2025 Chalhoub Group. All rights reserved.
 */

namespace Kharvi\GiftWithPurchase\Model\Rule\Metadata;

class ValueProvider extends \Magento\SalesRule\Model\Rule\Metadata\ValueProvider
{
    const FREE_GIFT ='free_gift_rule';
    const IS_FREE_PRODUCT ='is_free_product';
}
