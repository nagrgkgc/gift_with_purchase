<?php

namespace Kharvi\GiftWithPurchase\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\DB\Ddl\Table;

class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * @var EavSetupFactory
     */
    private $eavSetupFactory;

    /**
     * UpgradeSchema constructor.
     * @param EavSetupFactory $eavSetupFactory
     */
    public function __construct(EavSetupFactory $eavSetupFactory)
    {
        $this->eavSetupFactory = $eavSetupFactory;
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();
        $connection = $installer->getConnection();
        
        if (version_compare($context->getVersion(), '1.0.2') < 0) {
            $connection->addColumn($installer->getTable('quote_item'), 'is_free_product', [
                'type'     => Table::TYPE_INTEGER,
                'nullable' => true,
                'comment'  => 'Is Free Product'
            ]);
            
            $connection->addColumn($installer->getTable('sales_order_item'), 'is_free_product', [
                'type'     => Table::TYPE_INTEGER,
                'nullable' => true,
                'comment'  => 'Is Free Product'
            ]);
        }

        $installer->endSetup();
    }
}
