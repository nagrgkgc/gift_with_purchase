<?php
/**
 * Copyright © 2020-2025 Chalhoub Group. All rights reserved.
 */

namespace Kharvi\GiftWithPurchase\Plugin;

use Magento\Checkout\CustomerData\ItemPoolInterface;

class GiftProductInMiniCart
{
    /**
     * @var ItemPoolInterface
     */
    private $itemPoolInterface;

    /**
     * @var \Magento\Customer\Model\Session
     */
    private $checkoutSession;

    /**
     * GiftProductInMiniCart constructor.
     * @param ItemPoolInterface $itemPoolInterface
     * @param \Magento\Checkout\Model\Session $checkoutSession
     */
    public function __construct(
        ItemPoolInterface $itemPoolInterface,
        \Magento\Checkout\Model\Session $checkoutSession
    ) {
        $this->itemPoolInterface = $itemPoolInterface;
        $this->checkoutSession = $checkoutSession;
    }

    /**
     * @param \Magento\Checkout\CustomerData\Cart $subject
     * @param $result
     * @return mixed
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function afterGetSectionData(\Magento\Checkout\CustomerData\Cart $subject, $result)
    {
        if (isset($result['items'])) {
            $items = $result['items'];

            foreach ($this->checkoutSession->getQuote()->getAllVisibleItems() as $item) {
                if ($item->getIsFreeProduct()) {
                    $items[] = $this->itemPoolInterface->getItemData($item);
                    break;
                }
            }

            $result['items'] = $items;
        }

        return $result;
    }
}
