<?php
/**
 * Copyright © 2020-2025 Chalhoub Group. All rights reserved.
 */

namespace Kharvi\GiftWithPurchase\Plugin\Rule\Metadata;

class ValueProvider
{
    /**
     * @param \Magento\SalesRule\Model\Rule\Metadata\ValueProvider $subject
     * @param $result
     * @return mixed
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function afterGetMetadataValues(
        \Magento\SalesRule\Model\Rule\Metadata\ValueProvider $subject,
        $result
    ) {
        $applyOptions = [
            'label' => __('Free Gift Rule'),
            'value' => [
                [
                    'label' => 'Free Gift Rule',
                    'value' => \Kharvi\GiftWithPurchase\Model\Rule\Metadata\ValueProvider::FREE_GIFT,
                ]
            ],
        ];
        array_push(
            $result['actions']['children']['simple_action']['arguments']['data']['config']['options'],
            $applyOptions
        );
        return $result;
    }
}
