<?php

namespace Kharvi\GiftWithPurchase\Plugin\Model;

use Magento\Checkout\Model\DefaultConfigProvider as ConfigProvider;
use Magento\Checkout\Model\Session;
use Magento\Sales\Api\Data\OrderItemInterface;

/**
 * Class DefaultConfigProvider
 * @package LevelShoes\Checkout\Plugin\Model
 */
class DefaultConfigProvider
{
    /**
     * @var Session
     */
    private $checkoutSession;

    /**
     * DefaultConfigProvider constructor.
     * @param Session $checkoutSession
     */
    public function __construct(
        Session $checkoutSession
    ) {
        $this->checkoutSession = $checkoutSession;
    }

    /**
     * @param ConfigProvider $subject
     * @param array $result
     * @return mixed
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function afterGetConfig(
        ConfigProvider $subject,
        array $result
    ) {
        $items = $result['totalsData']['items'];
        foreach ($items as $index => $item) {
            $quote = $this->checkoutSession->getQuote();
            $quoteItem = $quote->getItemById($item[OrderItemInterface::ITEM_ID]);

            $result['quoteItemData'][$index]
            [\Kharvi\GiftWithPurchase\Model\Rule\Metadata\ValueProvider::IS_FREE_PRODUCT]
                = $quoteItem->getIsFreeProduct();
        }

        return $result;
    }
}
