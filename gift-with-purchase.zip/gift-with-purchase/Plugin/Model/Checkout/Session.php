<?php

namespace Kharvi\GiftWithPurchase\Plugin\Model\Checkout;

/**
 * @api
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Session
{
    /**
     * @param \Magento\Checkout\Model\Session $subject
     * @return $this
     */
    public function afterClearQuote(
        \Magento\Checkout\Model\Session $subject
    ) {
        $subject->unsRemovedFreeProduct();
        return $this;
    }
}
