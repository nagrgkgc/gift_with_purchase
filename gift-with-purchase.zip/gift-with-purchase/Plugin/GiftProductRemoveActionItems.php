<?php

namespace Kharvi\GiftWithPurchase\Plugin;

use Magento\Quote\Model\Quote\Item\AbstractItem;

class GiftProductRemoveActionItems
{
    /**
     * @param \Magento\Checkout\Block\Cart\Item\Renderer $subject
     * @param $result
     * @param AbstractItem $item
     * @return string
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function afterGetActions(
        \Magento\Checkout\Block\Cart\Item\Renderer $subject,
        $result,
        AbstractItem $item
    ) {
        $isFreeProduct = (bool)$item->getIsFreeProduct();
        
        if (!$isFreeProduct) {
            return $result;
        } else {
            return '';
        }
    }
}
