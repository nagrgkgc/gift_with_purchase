<?php
/**
 * Copyright © 2020-2025 Chalhoub Group. All rights reserved.
 */

namespace Kharvi\GiftWithPurchase\Plugin;

class UnsetFreeProductFlag
{
    /**
     * @var \Magento\Checkout\Model\Session
     */
    private $checkoutSession;

    /**
     * @var \Magento\Framework\App\Request\Http
     */
    private $request;

    /**
     * UnsetFreeProductFlag constructor.
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Magento\Framework\App\Request\Http $request
     */
    public function __construct(
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Framework\App\Request\Http $request
    ) {
        $this->checkoutSession = $checkoutSession;
        $this->request = $request;
    }

    /**
     * @param \Magento\Checkout\Controller\Cart $subject
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function beforeExecute(\Magento\Checkout\Controller\Cart $subject)
    {
        $flag = (int)$this->checkoutSession->getRemovedFreeProduct();
        $paramFreeProduct = (int)$this->request->getParam('fg');

        if ($flag && $paramFreeProduct) {
            $this->checkoutSession->setRemovedFreeProduct(0);
        }
    }
}
