<?php

namespace Kharvi\GiftWithPurchase\Plugin\CustomerData;

use Magento\Checkout\CustomerData\AbstractItem as Subject;
use Magento\Quote\Model\Quote\Item;

/**
 * Class AbstractItem
 * @package Kharvi\GiftWithPurchase\Plugin\CustomerData
 */
class AbstractItem
{
    /**
     * @param Subject $subject
     * @param array $result
     * @param Item $item
     * @return array
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function afterGetItemData(
        Subject $subject,
        array $result,
        Item $item
    ) {
        if (is_array($result)) {
            $result[\Kharvi\GiftWithPurchase\Model\Rule\Metadata\ValueProvider::IS_FREE_PRODUCT]
                = $item->getIsFreeProduct();
        }

        return $result;
    }
}
