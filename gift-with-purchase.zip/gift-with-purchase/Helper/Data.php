<?php


namespace Kharvi\GiftWithPurchase\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * @var \Magento\Framework\DB\Adapter\AdapterInterface
     */
    private $connection;

    /**
     * @var \Magento\Catalog\Api\ProductRepositoryInterface
     */
    private $productRepository;

    /**
     * @var \Magento\Quote\Api\Data\CartItemInterfaceFactory
     */
    private $cartItemFactory;

    /**
     * @var \Magento\Framework\App\ResourceConnection
     */
    private $resourceConnection;

    /**
     * Data constructor.
     * @param \Magento\Framework\App\ResourceConnection $resourceConnection
     * @param \Magento\Catalog\Api\ProductRepositoryInterface $productRepository
     * @param \Magento\Quote\Api\Data\CartItemInterfaceFactory $cartItemFactory
     * @param \Magento\Framework\App\Helper\Context $context
     */
    public function __construct(
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \Magento\Quote\Api\Data\CartItemInterfaceFactory $cartItemFactory,
        \Magento\Framework\App\Helper\Context $context
    ) {
        parent::__construct($context);

        $this->productRepository = $productRepository;
        $this->resourceConnection = $resourceConnection;
        $this->cartItemFactory = $cartItemFactory;
        $this->connection = $this->resourceConnection->getConnection();
    }

    /**
     * @param $ruleId
     * @param $sku
     * @param $storeId
     * @param $qty
     * @return \Magento\Quote\Api\Data\CartItemInterface|string
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function _getFreeQuoteItem($sku, $storeId, $qty)
    {
        if ($qty < 1) {
            return '';
        }

        $product = $this->productRepository->get($sku, false, $storeId);

        if ($product == false) {
            return '';
        }

        if (!$product->isSalable()) {
            return '';
        }

        $quoteItem = $this->cartItemFactory->create();
        $quoteItem->setProduct($product);

        $quoteItem
            ->setQty($qty)
            ->setPrice($product->getPrice())
            ->setIsFreeProduct(true)
            ->setStoreId($storeId);

        return $quoteItem;
    }

    /**
     * @param $quote
     * @param $giftSku
     * @param $qty
     * @param $rule
     */
    public function removeCoupon($quote, $giftSku, $qty, $rule)
    {
        $couponCode = $quote->getCouponCode();
        $gCouponCode = $rule->getCode(); // generated coupon code

        $qtyArray = $this->checkCouponCodes($giftSku, $couponCode, $rule, $gCouponCode, $qty);
        $this->setCouponToEmpty($quote, $qtyArray);
    }

    /**
     * @param $giftSku
     * @param $couponCode
     * @param $rule
     * @param $gCouponCode
     * @param $qty
     */
    private function checkCouponCodes($giftSku, $couponCode, $rule, $gCouponCode, $qty)
    {
        if (isset($giftSku) && !empty($giftSku) && isset($couponCode)
            && !empty($couponCode) && (($couponCode == $rule->getCouponCode()) || (isset($gCouponCode)
                    && !empty($gCouponCode) && $couponCode == $gCouponCode))) {
            $qtyArray = $this->getStockStatusBySku($qty, $giftSku);

            return $qtyArray;
        }

        return [];
    }

    /**
     * @param $quote
     * @param $qtyArray
     */
    private function setCouponToEmpty($quote, $qtyArray)
    {
        if (count($qtyArray)> 0) {
            $quote->setCouponCode('');
            $quote->collectTotals()->save();
        }
    }

    /**
     * @param $quote
     * @param $giftSku
     * @param $qty
     * @return bool
     */
    public function validateGiftProduct($giftSku, $qty)
    {
        if (isset($giftSku) && !empty($giftSku)) {
            $qtyArray = $this->getStockStatusBySku($qty, $giftSku);
            if (count($qtyArray)> 0) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param $qty
     * @param $giftSku
     * @return array
     */
    private function getStockStatusBySku($qty, $giftSku)
    {
        //to change in 2.3 upgrade
        $sql = "select e.sku, csi.qty from catalog_product_entity as e 
        inner join cataloginventory_stock_item as csi on e.entity_id = csi.product_id 
        where  (csi.qty <= 0 OR  csi.qty < :qty OR :qty <= 0 OR csi.is_in_stock = 0) 
        and FIND_IN_SET(e.sku ,:sku)";
        $qtyArray = $this->connection->fetchAll($sql, ['qty' => $qty, 'sku' => $giftSku]);

        return $qtyArray;
    }
}
