<?php
namespace Kharvi\GiftWithPurchase\Model\Rule\Action\Discount;

class FreeGift extends \Magento\SalesRule\Model\Rule\Action\Discount\AbstractDiscount
{
    protected $_checkoutSession;
    protected $_productRepository;
    protected $_connection;
    protected $_resourceConnection;
    protected $_productObject;
    protected $_messageManager;
    protected $_cartItemFactory;
    protected $discountFactory;

    public function __construct(
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \Magento\Catalog\Model\Product $productObject,
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Quote\Api\Data\CartItemInterfaceFactory $cartItemFactory,
        \Magento\SalesRule\Model\Rule\Action\Discount\DataFactory $discountDataFactory
    ) {
        $this->_checkoutSession = $checkoutSession;
        $this->_productRepository = $productRepository;
        $this->_productObject = $productObject;
        $this->_resourceConnection = $resourceConnection;
        $this->_messageManager = $messageManager;
        $this->_cartItemFactory = $cartItemFactory;
        $this->discountFactory = $discountDataFactory;

        $this->_connection = $this->_resourceConnection->getConnection();
    }

    /**
     * @param \Magento\SalesRule\Model\Rule $rule
     * @param \Magento\Quote\Model\Quote\Item\AbstractItem $item
     * @param float $qty
     * @return Data
     */
    public function calculate($rule, $item, $qty){
        $discountData = $this->_calculate($rule, $item, $qty);
        $this->_checkoutSession->setFreeGiftApplied(1);

        //get rule action
        $action = $rule->getSimpleAction();

        //get quote
        $quote = $this->_checkoutSession->getQuote(); //get quote

        //get sku
        $sku = $rule->getGiftSku();

        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/test.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info($action);

        //check if empty field
        if(empty($sku) || $sku == '' || $qty==0){
            return $discountData;
        }

        $this->removeCoupon($quote,$sku,$qty,$rule);
        if($item->getIsFreeProduct()
            || $this->_checkoutSession->getRemovedFreeProduct()
            || $this->_checkoutSession->getFreeProductApplied()
            || $this->validateGiftProduct($quote,$sku,$qty))
        {
            return $discountData;
        }

        try{
            $freeItem = $this->_getFreeQuoteItem($rule->getId(), $sku, $item->getStoreId(), $qty);

            if(!empty($freeItem) && $freeItem!='') {
                $quote->addItem($freeItem);
                //$this->_setQuoteItemTaxPercent($freeItem);
                $freeItem->setApplyingRule($rule);
                $this->_checkoutSession->setFreeProductApplied(1);

                //$this->_messageManager->addSuccessMessage(__('Free gift has been added to shopping bag.'));
            }
        } catch (\Exception $e) {
            throw new \Exception(sprintf(
                $e->getMessage()
            ));
        }

        return $discountData;
    }

    /**
     * @param float $qty
     * @param \Magento\SalesRule\Model\Rule $rule
     * @return float
     */
    public function fixQuantity($qty, $rule){
        $step = $rule->getDiscountStep();
        if ($step){
            $qty = floor($qty / $step) * $step;
        }

        return $qty;
    }

    /**
     * @param \Magento\SalesRule\Model\Rule $rule
     * @param \Magento\Quote\Model\Quote\Item\AbstractItem $item
     * @param float $qty
     * @param float $rulePercent
     * @return Data
     */
    protected function _calculate($rule, $item, $qty){
        $discountData = $this->discountFactory->create();
        // $discountData->setAmount();
        //Programar nueva regla aqui
        return $discountData;
    }

    public function removeCoupon($quote,$giftSku,$qty,$rule){
        $couponCode = $quote->getCouponCode();
        $gCouponCode = $rule->getCode(); // generated coupon code
        if(isset($giftSku) && !empty($giftSku) && isset($couponCode) && !empty($couponCode) && (($couponCode == $rule->getCouponCode()) OR (isset($gCouponCode) && !empty($gCouponCode) && $couponCode == $gCouponCode))){
            $sql = "select e.sku, csi.qty from catalog_product_entity as e inner join cataloginventory_stock_item as csi on e.entity_id = csi.product_id where  (csi.qty <= 0 OR  csi.qty < ".$qty." OR ".$qty." <= 0 OR csi.is_in_stock = 0) and FIND_IN_SET(e.sku ,'".$giftSku."')";
            $qtyArray = $this->_connection->fetchAll($sql);
            if(count($qtyArray)> 0){
                $quote->setCouponCode('');
                $quote->collectTotals()->save();
                //$this->_messageManager->addError(__('Sorry! Invalid Coupon, Gift Product has been removed.'));
            }
        }
    }

    protected function _getFreeQuoteItem($ruleId, $sku, $storeId, $qty)
    {
        if ($qty < 1) {
            /*throw new \Exception(sprintf(
                'Invalid Gift product qty. Rule ID: %d, Gift Qty: %d',
                $ruleId, $qty
            ));*/
            return '';
        }

        $product = $this->_productRepository->get($sku);
        $entityId = $product->getId();

        $product = $this->_productObject->setStoreId($storeId);
        $product->load($entityId);

        if ($product == false) {
            /*throw new \Exception(sprintf(
                'Gift product not found. Rule ID: %d, Gift SKU: %s, Store ID: %d',
                $ruleId, $sku, $storeId
            ));*/
            return '';
        }

        if ($product->isSalable() == false) {
            /*throw new \Exception(sprintf(
                'Gift product not saleable. Rule ID: %d, Gift SKU: %s, Store ID: %d',
                $ruleId, $sku, $storeId
            ));*/
            return '';
        }

        $quoteItem = $this->_cartItemFactory->create();
        $quoteItem->setProduct($product);

        $quoteItem
            ->setQty($qty)
            ->setPrice(0)
            ->setIsFreeProduct(true)
            ->setStoreId($storeId);

        return $quoteItem;
    }

    public function validateGiftProduct($quote,$giftSku,$qty){
        if(isset($giftSku) && !empty($giftSku)){
            $sql = "select e.sku, csi.qty from catalog_product_entity as e inner join cataloginventory_stock_item as csi on e.entity_id = csi.product_id where  (csi.qty <= 0 OR  csi.qty < ".$qty." OR ".$qty." <= 0 OR csi.is_in_stock = 0) and FIND_IN_SET(e.sku ,'".$giftSku."')";
            $qtyArray = $this->_connection->fetchAll($sql);
            if(count($qtyArray)> 0){
                return true;
            }
        }

        return false;
    }
}