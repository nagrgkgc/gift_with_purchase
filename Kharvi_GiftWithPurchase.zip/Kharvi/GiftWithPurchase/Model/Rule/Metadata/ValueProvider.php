<?php
namespace Kharvi\GiftWithPurchase\Model\Rule\Metadata;

class ValueProvider extends \Magento\SalesRule\Model\Rule\Metadata\ValueProvider
{
    const FREE_GIFT ='free_gift_rule';
}