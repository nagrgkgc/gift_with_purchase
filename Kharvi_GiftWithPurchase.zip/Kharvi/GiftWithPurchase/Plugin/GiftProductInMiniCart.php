<?php
namespace Kharvi\GiftWithPurchase\Plugin;

use Magento\Checkout\CustomerData\ItemPoolInterface;

class GiftProductInMiniCart
{
    /**
     * @var ItemPoolInterface
     */
    protected $itemPoolInterface;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $checkoutSession;

    public function __construct(
        ItemPoolInterface $itemPoolInterface,
        \Magento\Checkout\Model\Session $checkoutSession
    )
    {
        $this->itemPoolInterface = $itemPoolInterface;
        $this->checkoutSession = $checkoutSession;
    }

    public function afterGetSectionData(\Magento\Checkout\CustomerData\Cart $subject, $result)
    {
        if(isset($result['items'])){
            $items = $result['items'];

            foreach ($this->checkoutSession->getQuote()->getAllVisibleItems() as $item) {
                if($item->getIsFreeProduct()){
                    $items[] = $this->itemPoolInterface->getItemData($item);
                    break;
                }
            }

            $result['items'] = $items;
        }

        return $result;
    }
}