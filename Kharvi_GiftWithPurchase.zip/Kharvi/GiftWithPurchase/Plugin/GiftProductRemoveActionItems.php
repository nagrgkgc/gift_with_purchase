<?php
namespace Kharvi\GiftWithPurchase\Plugin;
use Magento\Quote\Model\Quote\Item\AbstractItem;

class GiftProductRemoveActionItems
{
    public function afterGetActions(
        \Magento\Checkout\Block\Cart\Item\Renderer $subject, $result, AbstractItem $item
    ) {
        $isFreeProduct = (bool)$item->getIsFreeProduct();
        
        if(!$isFreeProduct){
            return $result;
        }else{
            return '';
        }
    }
}