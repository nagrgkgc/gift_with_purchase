<?php
namespace Kharvi\GiftWithPurchase\Plugin\Rule\Metadata;

class ValueProvider {
    public function afterGetMetadataValues(
        \Magento\SalesRule\Model\Rule\Metadata\ValueProvider $subject,
        $result
    ) {
        $applyOptions = [
            'label' => __('Free Gift Rule'),
            'value' => [
                [
                    'label' => 'Free Gift Rule',
                    'value' => 'free_gift_rule',
                ]
            ],
        ];
        array_push($result['actions']['children']['simple_action']['arguments']['data']['config']['options'], $applyOptions);
        return $result;
    }
}