<?php
namespace Kharvi\GiftWithPurchase\Plugin;

class UnsetFreeProductFlag
{
    protected $_checkoutSession;
    protected $_request;

    public function __construct(
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Framework\App\Request\Http $request
    )
    {
        $this->_checkoutSession = $checkoutSession;
        $this->_request = $request;
    }

    public function beforeExecute(\Magento\Checkout\Controller\Cart $subject)
    {
        $flag = (int)$this->_checkoutSession->getRemovedFreeProduct();
        $paramFreeProduct = (int)$this->_request->getParam('fg');

        if($flag && $paramFreeProduct){
            $this->_checkoutSession->setRemovedFreeProduct(0);
        }
    }


}