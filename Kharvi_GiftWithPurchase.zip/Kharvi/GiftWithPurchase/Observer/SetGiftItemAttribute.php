<?php
namespace Kharvi\GiftWithPurchase\Observer;
 
use Magento\Framework\Event\ObserverInterface;
 
class SetGiftItemAttribute implements ObserverInterface
{
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $quoteItem = $observer->getQuoteItem();
        $product = $observer->getProduct();
        if($product->getIsFreeProduct()){
            $quoteItem->setIsFreeProduct(1);
        }
    }
}