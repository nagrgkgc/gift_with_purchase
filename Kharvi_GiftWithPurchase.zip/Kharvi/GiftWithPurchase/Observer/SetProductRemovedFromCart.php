<?php
namespace Kharvi\GiftWithPurchase\Observer;

use Magento\Framework\Event\ObserverInterface;

class SetProductRemovedFromCart implements ObserverInterface{
    protected $_checkoutSession;
    protected $_request;

    public function __construct(
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Framework\App\Request\Http $request
    ){
        $this->_checkoutSession = $checkoutSession;
        $this->_request = $request;
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $quoteItem = $observer->getEvent()->getQuoteItem(); //get item
        $action     = $this->_request->getActionName();
        $controller = $this->_request->getControllerName();

        if($_SERVER['REQUEST_METHOD'] == 'POST' && $controller == 'cart' && $action == 'delete' && $quoteItem->getIsFreeProduct()){
            $this->_checkoutSession->setRemovedFreeProduct(1);
        }
    }
}