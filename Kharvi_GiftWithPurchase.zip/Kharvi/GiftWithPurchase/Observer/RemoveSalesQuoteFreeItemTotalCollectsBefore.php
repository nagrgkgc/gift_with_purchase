<?php
namespace Kharvi\GiftWithPurchase\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer as EventObserver;
use Magento\SalesRule\Api\Exception\CodeRequestLimitException;
use Magento\SalesRule\Model\Spi\CodeLimitManagerInterface;

class RemoveSalesQuoteFreeItemTotalCollectsBefore implements ObserverInterface{
    protected $_checkoutSession;
    protected $_cartSession;
    protected $_messageManager;
    
    public function __construct(
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Checkout\Model\Cart $cartSession,
        \Magento\Framework\Message\ManagerInterface $messageManager
    ){
        $this->_checkoutSession = $checkoutSession;
        $this->_cartSession = $cartSession;
        $this->_messageManager = $messageManager;
    }
    
    public function execute(EventObserver $observer){
        $quote = $observer->getData('quote');

        $originalStore = $quote->getStoreId();
		foreach ($quote->getAllItems() as $item) {
            if ($item->getIsFreeProduct()) {
				$quote->removeItem($item->getId());
            }
        }
        
        $this->_checkoutSession->unsFreeProductApplied();
        $this->_checkoutSession->unsFreeGiftApplied();

        $quote->setStoreId($originalStore);
    }
}